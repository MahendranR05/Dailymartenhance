import { NextResponse } from 'next/server'
import { products, categories, money } from '@/lib/catalog'

export const runtime = 'nodejs'

function localReply(message: string): string {
  const q = message.toLowerCase()
  const cap = q.match(/(?:under|below|less than|within|upto|up to)\s*(?:₹|rs\.?|inr)?\s*(\d+)/)
  const maxPrice = cap ? Number(cap[1]) : null
  const cat = categories.find(c => q.includes(c.name.toLowerCase()) || q.includes(c.short.toLowerCase()))
    || (/electronic|tech|gadget/.test(q) ? categories.find(c => c.name === 'Electronics') : undefined)
    || (/grocer|fruit|veg|fresh/.test(q) ? categories.find(c => c.name === 'Fruits & Vegetables') : undefined)
  const list = (items: typeof products) => items.slice(0, 5).map(p => `• ${p.name} — ${money(p.price)} (${p.unit})`).join('\n')

  if (/pay|upi|card|cod|cash/.test(q)) return 'You can pay with UPI, credit/debit card (securely via Razorpay) or cash on delivery. Open your bag and choose Continue to secure checkout.'
  if (/deliver|shipping|return|refund/.test(q)) return 'Pick or add a delivery address from the "Deliver to" button at the top. Delivery is free on all orders in this store.'
  if (maxPrice || cat) {
    const found = products.filter(p => (!cat || p.category === cat.name) && (!maxPrice || p.price <= maxPrice)).sort((a, b) => a.price - b.price)
    if (found.length) return `Here are some picks${cat ? ` in ${cat.name}` : ''}${maxPrice ? ` under ${money(maxPrice)}` : ''}:\n${list(found)}`
    return 'I couldn’t find anything matching that. Try a different category or budget.'
  }
  const words = q.split(/\W+/).filter(w => w.length > 2)
  const hits = products.filter(p => words.some(w => `${p.name} ${p.category} ${p.description}`.toLowerCase().includes(w)))
  if (hits.length) return `These might be what you’re looking for:\n${list(hits)}`
  return 'I can help you find products, compare prices, or explain payment and delivery. Try “Show me electronics” or “What can I buy under ₹500?”'
}

export async function POST(request: Request) {
  let message = ''
  try { message = String((await request.json())?.message ?? '').trim().slice(0, 500) } catch {}
  if (!message) return NextResponse.json({ reply: 'Ask me anything about our products, prices or checkout.' }, { status: 400 })

  const key = process.env.OPENAI_API_KEY
  if (key) {
    try {
      const catalog = products.map(p => `${p.name} | ${p.category} | ${money(p.price)} | ${p.unit}`).join('\n')
      const res = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
        body: JSON.stringify({
          model: process.env.OPENAI_MODEL || 'gpt-4o-mini', max_tokens: 300,
          messages: [
            { role: 'system', content: `You are Daily, the shopping assistant for DailyMart, an Indian online store. Answer briefly. Only recommend products from this catalog; never invent products or prices.\n${catalog}` },
            { role: 'user', content: message },
          ],
        }),
      })
      const data = await res.json()
      const reply = data?.choices?.[0]?.message?.content
      if (res.ok && reply) return NextResponse.json({ reply })
    } catch {}
  }
  return NextResponse.json({ reply: localReply(message) })
}

import { NextResponse } from 'next/server'
import crypto from 'node:crypto'
import { priceItems, validAddress } from '@/lib/server-pricing'

export const runtime = 'nodejs'

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const priced = priceItems(body?.items)
    if ('error' in priced) return NextResponse.json({ error: priced.error }, { status: 400 })
    if (!validAddress(body?.address)) return NextResponse.json({ error: 'Please choose a valid delivery address.' }, { status: 400 })
    const orderId = `DM-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(2).toString('hex').toUpperCase()}`
    return NextResponse.json({ orderId, total: priced.total, items: priced.lines, paymentMethod: 'cod' })
  } catch {
    return NextResponse.json({ error: 'Could not place order.' }, { status: 400 })
  }
}

import { NextResponse } from 'next/server'
import crypto from 'node:crypto'

export const runtime = 'nodejs'

export async function POST(request: Request) {
  const secret = process.env.RAZORPAY_KEY_SECRET
  if (!secret) return NextResponse.json({ verified: false, error: 'Payments are not configured.' }, { status: 503 })
  try {
    const { orderId, paymentId, signature } = await request.json()
    if (![orderId, paymentId, signature].every(v => typeof v === 'string' && v.length > 0 && v.length < 200)) {
      return NextResponse.json({ verified: false, error: 'Missing payment verification data.' }, { status: 400 })
    }
    const expected = Buffer.from(crypto.createHmac('sha256', secret).update(`${orderId}|${paymentId}`).digest('hex'))
    const received = Buffer.from(signature)
    const verified = expected.length === received.length && crypto.timingSafeEqual(expected, received)
    return NextResponse.json({ verified }, { status: verified ? 200 : 400 })
  } catch {
    return NextResponse.json({ verified: false, error: 'Could not verify payment.' }, { status: 400 })
  }
}

import { NextResponse } from 'next/server'
import { priceItems } from '@/lib/server-pricing'

export const runtime = 'nodejs'

export async function POST(request: Request) {
  const keyId = process.env.RAZORPAY_KEY_ID
  const keySecret = process.env.RAZORPAY_KEY_SECRET
  if (!keyId || !keySecret) {
    return NextResponse.json({ error: 'Payments are not configured. Add RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET to .env.local and restart the server.' }, { status: 503 })
  }
  try {
    const body = await request.json()
    const priced = priceItems(body?.items)
    if ('error' in priced) return NextResponse.json({ error: priced.error }, { status: 400 })

    const res = await fetch('https://api.razorpay.com/v1/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Basic ${Buffer.from(`${keyId}:${keySecret}`).toString('base64')}` },
      // Razorpay amounts are in paise (₹1 = 100 paise); total is computed on the server.
      body: JSON.stringify({ amount: Math.round(priced.total * 100), currency: 'INR', receipt: `dm_${Date.now()}`.slice(0, 40), notes: { items: priced.lines.map(l => `${l.id}x${l.quantity}`).join(',').slice(0, 250) } }),
    })
    const order = await res.json().catch(() => ({}))
    if (!res.ok) return NextResponse.json({ error: order?.error?.description || 'Razorpay could not create the order. Check your API keys.' }, { status: 502 })
    return NextResponse.json({ id: order.id, amount: order.amount, currency: order.currency, keyId })
  } catch {
    return NextResponse.json({ error: 'Could not start payment.' }, { status: 400 })
  }
}

import { NextResponse } from 'next/server'
import { checkLogin, startSession } from '@/lib/auth'
export const runtime = 'nodejs'
export async function POST(request: Request) {
  try {
    const b = await request.json()
    const user = checkLogin(String(b?.email ?? '').trim().toLowerCase(), String(b?.password ?? ''))
    if (!user) return NextResponse.json({ error: 'Incorrect email or password.' }, { status: 401 })
    await startSession(user.id)
    return NextResponse.json({ user: { name: user.name, email: user.email } })
  } catch { return NextResponse.json({ error: 'Could not log in.' }, { status: 500 }) }
}

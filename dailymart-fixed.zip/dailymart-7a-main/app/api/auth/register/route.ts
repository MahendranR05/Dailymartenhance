import { NextResponse } from 'next/server'
import { createUser, startSession } from '@/lib/auth'
export const runtime = 'nodejs'
export async function POST(request: Request) {
  try {
    const b = await request.json()
    const name = String(b?.name ?? '').trim(), email = String(b?.email ?? '').trim().toLowerCase(), password = String(b?.password ?? '')
    if (!name || name.length > 100 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254 || password.length < 8 || password.length > 128)
      return NextResponse.json({ error: 'Enter your name, a valid email and a password of at least 8 characters.' }, { status: 400 })
    const user = createUser(name, email, password)
    if (!user) return NextResponse.json({ error: 'An account with this email already exists.' }, { status: 409 })
    await startSession(user.id)
    return NextResponse.json({ user: { name: user.name, email: user.email } })
  } catch { return NextResponse.json({ error: 'Could not create account.' }, { status: 500 }) }
}

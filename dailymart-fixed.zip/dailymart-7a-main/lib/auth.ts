import crypto from 'node:crypto'
import fs from 'node:fs'
import path from 'node:path'
import { cookies } from 'next/headers'

// Simple file-backed accounts for local/dev use. Swap for a real database before deploying to serverless hosting.
const FILE = path.join(process.cwd(), 'data', 'users.json')
const COOKIE = 'dm_session'
type User = { id: string; name: string; email: string; salt: string; hash: string }

const secret = () => process.env.AUTH_SECRET || (process.env.NODE_ENV === 'production' ? '' : 'dev-only-secret-change-me')
const readUsers = (): User[] => { try { return JSON.parse(fs.readFileSync(FILE, 'utf8')) } catch { return [] } }
const writeUsers = (u: User[]) => { fs.mkdirSync(path.dirname(FILE), { recursive: true }); fs.writeFileSync(FILE, JSON.stringify(u, null, 2)) }
const hashPw = (pw: string, salt: string) => crypto.scryptSync(pw, salt, 64).toString('hex')
const sign = (v: string) => crypto.createHmac('sha256', secret()).update(v).digest('hex')

export function createUser(name: string, email: string, password: string): User | null {
  const users = readUsers()
  if (users.some(u => u.email === email)) return null
  const salt = crypto.randomBytes(16).toString('hex')
  const user = { id: crypto.randomUUID(), name, email, salt, hash: hashPw(password, salt) }
  writeUsers([...users, user]); return user
}
export function checkLogin(email: string, password: string): User | null {
  const u = readUsers().find(x => x.email === email); if (!u) return null
  const a = Buffer.from(hashPw(password, u.salt)), b = Buffer.from(u.hash)
  return a.length === b.length && crypto.timingSafeEqual(a, b) ? u : null
}
export async function startSession(userId: string) {
  if (!secret()) throw new Error('AUTH_SECRET is not set')
  const exp = Date.now() + 7 * 864e5, v = `${userId}.${exp}`
  ;(await cookies()).set(COOKIE, `${v}.${sign(v)}`, { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', path: '/', maxAge: 7 * 86400 })
}
export async function endSession() { (await cookies()).delete(COOKIE) }
export async function currentUser(): Promise<{ id: string; name: string; email: string } | null> {
  if (!secret()) return null
  const raw = (await cookies()).get(COOKIE)?.value; if (!raw) return null
  const [id, exp, sig] = raw.split('.'); if (!id || !exp || !sig) return null
  const good = sign(`${id}.${exp}`); if (sig.length !== good.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(good)) || Number(exp) < Date.now()) return null
  const u = readUsers().find(x => x.id === id); return u ? { id: u.id, name: u.name, email: u.email } : null
}

import { products, type Address } from '@/lib/catalog'

export type OrderLine = { id: string; name: string; quantity: number; price: number }

/** Re-prices a cart on the server from the catalog. Never trust prices sent by the browser. */
export function priceItems(raw: unknown): { lines: OrderLine[]; total: number } | { error: string } {
  if (!Array.isArray(raw) || raw.length === 0 || raw.length > 50) return { error: 'Your bag is empty or invalid.' }
  const merged = new Map<string, number>()
  for (const item of raw) {
    const id = typeof item?.id === 'string' ? item.id : ''
    const quantity = Number(item?.quantity)
    if (!products.some(p => p.id === id)) return { error: 'One of the items is no longer available.' }
    if (!Number.isInteger(quantity) || quantity < 1 || quantity > 10) return { error: 'Invalid item quantity.' }
    merged.set(id, Math.min(10, (merged.get(id) || 0) + quantity))
  }
  const lines: OrderLine[] = [...merged].map(([id, quantity]) => {
    const p = products.find(x => x.id === id)!
    return { id, name: p.name, quantity, price: p.price }
  })
  const total = lines.reduce((sum, l) => sum + l.price * l.quantity, 0)
  return { lines, total }
}

export function validAddress(a: any): a is Address {
  const ok = (v: unknown, max: number) => typeof v === 'string' && v.trim().length > 0 && v.length <= max
  return !!a && ok(a.label, 40) && ok(a.name, 100) && ok(a.street, 200) && ok(a.city, 80) && typeof a.pin === 'string' && /^[1-9][0-9]{5}$/.test(a.pin)
}
